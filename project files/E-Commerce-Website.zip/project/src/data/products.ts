import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Organic Bananas',
    price: 2.99,
    image: 'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Fruits',
    description: 'Fresh organic bananas, perfect for smoothies and snacks',
    unit: 'bunch',
    inStock: true,
    rating: 4.5,
    reviews: 124
  },
  {
    id: '2',
    name: 'Fresh Strawberries',
    price: 4.99,
    image: 'https://images.pexels.com/photos/89778/strawberries-frisch-ripe-sweet-89778.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Fruits',
    description: 'Sweet, juicy strawberries picked at peak ripeness',
    unit: 'lb',
    inStock: true,
    rating: 4.8,
    reviews: 89
  },
  {
    id: '3',
    name: 'Organic Spinach',
    price: 3.49,
    image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Vegetables',
    description: 'Fresh organic spinach leaves, packed with nutrients',
    unit: 'bunch',
    inStock: true,
    rating: 4.3,
    reviews: 67
  },
  {
    id: '4',
    name: 'Whole Milk',
    price: 3.99,
    image: 'https://images.pexels.com/photos/236010/pexels-photo-236010.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Dairy',
    description: 'Fresh whole milk from local farms',
    unit: 'gallon',
    inStock: true,
    rating: 4.6,
    reviews: 156
  },
  {
    id: '5',
    name: 'Artisan Bread',
    price: 5.99,
    image: 'https://images.pexels.com/photos/209206/pexels-photo-209206.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Bakery',
    description: 'Freshly baked artisan sourdough bread',
    unit: 'loaf',
    inStock: true,
    rating: 4.7,
    reviews: 93
  },
  {
    id: '6',
    name: 'Premium Ground Beef',
    price: 8.99,
    image: 'https://images.pexels.com/photos/3688/food-dinner-lunch-unhealthy.jpg?auto=compress&cs=tinysrgb&w=500',
    category: 'Meat',
    description: 'Fresh 80/20 ground beef, perfect for burgers',
    unit: 'lb',
    inStock: true,
    rating: 4.4,
    reviews: 78
  },
  {
    id: '7',
    name: 'Organic Tomatoes',
    price: 3.99,
    image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Vegetables',
    description: 'Vine-ripened organic tomatoes, bursting with flavor',
    unit: 'lb',
    inStock: true,
    rating: 4.5,
    reviews: 112
  },
  {
    id: '8',
    name: 'Greek Yogurt',
    price: 4.49,
    image: 'https://images.pexels.com/photos/1152237/pexels-photo-1152237.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Dairy',
    description: 'Creamy Greek yogurt, high in protein',
    unit: 'container',
    inStock: true,
    rating: 4.6,
    reviews: 134
  },
  {
    id: '9',
    name: 'Fresh Salmon Fillet',
    price: 12.99,
    image: 'https://images.pexels.com/photos/725997/pexels-photo-725997.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Seafood',
    description: 'Atlantic salmon fillet, rich in omega-3',
    unit: 'lb',
    inStock: false,
    rating: 4.8,
    reviews: 87
  },
  {
    id: '10',
    name: 'Organic Avocados',
    price: 1.99,
    image: 'https://images.pexels.com/photos/557659/pexels-photo-557659.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Fruits',
    description: 'Perfectly ripe organic avocados',
    unit: 'each',
    inStock: true,
    rating: 4.4,
    reviews: 98
  },
  {
    id: '11',
    name: 'Organic Carrots',
    price: 2.49,
    image: 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Vegetables',
    description: 'Fresh organic carrots, sweet and crunchy',
    unit: 'bunch',
    inStock: true,
    rating: 4.3,
    reviews: 76
  },
  {
    id: '12',
    name: 'Croissants',
    price: 6.99,
    image: 'https://images.pexels.com/photos/2135/food-france-morning-breakfast.jpg?auto=compress&cs=tinysrgb&w=500',
    category: 'Bakery',
    description: 'Buttery, flaky croissants baked fresh daily',
    unit: 'pack of 6',
    inStock: true,
    rating: 4.7,
    reviews: 104
  }
];