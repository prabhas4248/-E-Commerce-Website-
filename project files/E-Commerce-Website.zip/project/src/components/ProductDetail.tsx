import { useEffect, useState } from 'react';
import { ArrowLeft, Star, ShoppingCart, Package } from 'lucide-react';
import type { Database } from '../lib/database.types';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ProductCard } from './ProductCard';

type Product = Database['public']['Tables']['products']['Row'];

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  onProductClick: (product: Product) => void;
}

export function ProductDetail({ product, onBack, onProductClick }: ProductDetailProps) {
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [recommendations, setRecommendations] = useState<Product[]>([]);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    trackView();
    fetchRecommendations();
  }, [product.id]);

  const trackView = async () => {
    await supabase.from('product_views').insert({
      user_id: user?.id || null,
      product_id: product.id,
    });
  };

  const fetchRecommendations = async () => {
    const { data } = await supabase
      .from('products')
      .select('*')
      .eq('category_id', product.category_id)
      .neq('id', product.id)
      .limit(4);

    if (data) setRecommendations(data);
  };

  const handleAddToCart = async () => {
    if (!user) return;
    for (let i = 0; i < quantity; i++) {
      await addToCart(product.id);
    }
    setQuantity(1);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to products</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm overflow-hidden mb-12">
          <div className="grid md:grid-cols-2 gap-8 p-8">
            <div className="aspect-square rounded-xl overflow-hidden bg-slate-100">
              <img
                src={product.image_url}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex flex-col">
              <div className="flex-1">
                {product.featured && (
                  <span className="inline-block bg-blue-100 text-blue-700 text-sm font-semibold px-3 py-1 rounded-full mb-4">
                    Featured Product
                  </span>
                )}

                <h1 className="text-3xl font-bold text-slate-900 mb-4">{product.name}</h1>

                <div className="flex items-center gap-2 mb-6">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < Math.floor(product.rating)
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-slate-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-slate-600">
                    {product.rating.toFixed(1)} ({Math.floor(Math.random() * 500) + 100} reviews)
                  </span>
                </div>

                <div className="text-4xl font-bold text-slate-900 mb-6">
                  ${product.price.toFixed(2)}
                </div>

                <p className="text-slate-600 text-lg leading-relaxed mb-6">{product.description}</p>

                <div className="flex items-center gap-2 mb-6">
                  <Package className="w-5 h-5 text-slate-500" />
                  <span className="text-slate-600">
                    {product.stock > 0 ? (
                      <>
                        <span className="font-semibold text-green-600">{product.stock}</span> in
                        stock
                      </>
                    ) : (
                      <span className="font-semibold text-red-600">Out of stock</span>
                    )}
                  </span>
                </div>
              </div>

              {user && product.stock > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <label className="text-slate-700 font-medium">Quantity:</label>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-10 h-10 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center font-bold transition-colors"
                      >
                        -
                      </button>
                      <span className="w-12 text-center font-semibold">{quantity}</span>
                      <button
                        onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                        className="w-10 h-10 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center font-bold transition-colors"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={handleAddToCart}
                    className="w-full flex items-center justify-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors text-lg font-semibold"
                  >
                    <ShoppingCart className="w-6 h-6" />
                    <span>Add to Cart</span>
                  </button>
                </div>
              )}

              {!user && (
                <div className="bg-slate-50 rounded-xl p-6 text-center">
                  <p className="text-slate-600">Sign in to purchase this product</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {recommendations.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-6">You May Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {recommendations.map((rec) => (
                <ProductCard key={rec.id} product={rec} onClick={() => onProductClick(rec)} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
