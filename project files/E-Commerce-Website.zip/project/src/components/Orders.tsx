import { useEffect, useState } from 'react';
import { ArrowLeft, Package, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { Database } from '../lib/database.types';

type Order = Database['public']['Tables']['orders']['Row'];
type OrderItem = Database['public']['Tables']['order_items']['Row'] & {
  products: Database['public']['Tables']['products']['Row'];
};

interface OrderWithItems extends Order {
  order_items: OrderItem[];
}

interface OrdersProps {
  onBack: () => void;
}

export function Orders({ onBack }: OrdersProps) {
  const { user } = useAuth();
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    if (!user) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('orders')
      .select('*, order_items(*, products(*))')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setOrders(data as OrderWithItems[]);
    }
    setLoading(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'shipped':
        return 'bg-purple-100 text-purple-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to shop</span>
        </button>

        <h1 className="text-3xl font-bold text-slate-900 mb-8">My Orders</h1>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : orders.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm p-12 text-center">
            <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-slate-900 mb-2">No orders yet</h2>
            <p className="text-slate-500">Start shopping to see your orders here</p>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="bg-slate-50 px-6 py-4 border-b flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600">
                      Order placed {new Date(order.created_at).toLocaleDateString()}
                    </p>
                    <p className="text-sm text-slate-600 mt-1">
                      Order ID: {order.id.slice(0, 8)}...
                    </p>
                  </div>
                  <div className="text-right">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(
                        order.status
                      )}`}
                    >
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                    <p className="text-lg font-bold text-slate-900 mt-2">
                      ${order.total.toFixed(2)}
                    </p>
                  </div>
                </div>

                <div className="p-6">
                  <div className="space-y-4">
                    {order.order_items.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="w-20 h-20 rounded-lg overflow-hidden bg-slate-100 flex-shrink-0">
                          <img
                            src={item.products.image_url}
                            alt={item.products.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-slate-900">{item.products.name}</h3>
                          <p className="text-sm text-slate-600 mt-1">Quantity: {item.quantity}</p>
                          <p className="text-sm font-semibold text-slate-900 mt-1">
                            ${item.price.toFixed(2)} each
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-slate-900">
                            ${(item.price * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {order.shipping_address && (
                    <div className="mt-6 pt-6 border-t">
                      <h4 className="font-semibold text-slate-900 mb-2">Shipping Address</h4>
                      <p className="text-sm text-slate-600">
                        {(order.shipping_address as { fullName?: string }).fullName}
                      </p>
                      <p className="text-sm text-slate-600">
                        {(order.shipping_address as { address?: string }).address}
                      </p>
                      <p className="text-sm text-slate-600">
                        {(order.shipping_address as { city?: string }).city},{' '}
                        {(order.shipping_address as { state?: string }).state}{' '}
                        {(order.shipping_address as { zipCode?: string }).zipCode}
                      </p>
                      <p className="text-sm text-slate-600">
                        {(order.shipping_address as { country?: string }).country}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
