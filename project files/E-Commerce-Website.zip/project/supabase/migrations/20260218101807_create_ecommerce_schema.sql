/*
  # E-Commerce Database Schema

  ## Overview
  Complete database schema for an e-commerce platform with products, shopping carts,
  orders, and user management.

  ## 1. New Tables

  ### `categories`
  - `id` (uuid, primary key) - Unique category identifier
  - `name` (text) - Category name
  - `slug` (text, unique) - URL-friendly category name
  - `description` (text) - Category description
  - `image_url` (text) - Category image URL
  - `created_at` (timestamptz) - Creation timestamp

  ### `products`
  - `id` (uuid, primary key) - Unique product identifier
  - `name` (text) - Product name
  - `slug` (text, unique) - URL-friendly product name
  - `description` (text) - Product description
  - `price` (decimal) - Product price
  - `image_url` (text) - Main product image URL
  - `category_id` (uuid, foreign key) - Reference to categories table
  - `stock` (integer) - Available stock quantity
  - `featured` (boolean) - Whether product is featured
  - `rating` (decimal) - Average product rating
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### `cart_items`
  - `id` (uuid, primary key) - Unique cart item identifier
  - `user_id` (uuid, foreign key) - Reference to auth.users
  - `product_id` (uuid, foreign key) - Reference to products table
  - `quantity` (integer) - Item quantity
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### `orders`
  - `id` (uuid, primary key) - Unique order identifier
  - `user_id` (uuid, foreign key) - Reference to auth.users
  - `total` (decimal) - Order total amount
  - `status` (text) - Order status (pending, processing, shipped, delivered, cancelled)
  - `shipping_address` (jsonb) - Shipping address details
  - `payment_intent_id` (text) - Stripe payment intent ID
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### `order_items`
  - `id` (uuid, primary key) - Unique order item identifier
  - `order_id` (uuid, foreign key) - Reference to orders table
  - `product_id` (uuid, foreign key) - Reference to products table
  - `quantity` (integer) - Item quantity
  - `price` (decimal) - Price at time of purchase
  - `created_at` (timestamptz) - Creation timestamp

  ### `product_views`
  - `id` (uuid, primary key) - Unique view identifier
  - `user_id` (uuid, foreign key) - Reference to auth.users (nullable for anonymous)
  - `product_id` (uuid, foreign key) - Reference to products table
  - `viewed_at` (timestamptz) - View timestamp

  ## 2. Security

  All tables have Row Level Security (RLS) enabled with appropriate policies:

  ### Categories & Products
  - Public read access for all users
  - No public write access (admin only via service role)

  ### Cart Items
  - Users can read, create, update, and delete their own cart items
  - Restricted to authenticated users only

  ### Orders & Order Items
  - Users can read their own orders and order items
  - Users can create new orders
  - No update or delete access (order history preservation)

  ### Product Views
  - Anyone can create product views (for anonymous tracking)
  - Users can read their own views

  ## 3. Important Notes

  - All foreign key constraints include ON DELETE CASCADE for data integrity
  - Default values are set for timestamps, booleans, and numeric fields
  - Indexes are created on foreign keys for query performance
  - RLS policies ensure users can only access their own data
  - Product views support both authenticated and anonymous users
*/

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  image_url text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  price decimal(10,2) NOT NULL,
  image_url text DEFAULT '',
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  stock integer DEFAULT 0,
  featured boolean DEFAULT false,
  rating decimal(3,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  quantity integer DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  total decimal(10,2) NOT NULL,
  status text DEFAULT 'pending',
  shipping_address jsonb NOT NULL,
  payment_intent_id text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  quantity integer NOT NULL,
  price decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create product_views table for AI recommendations
CREATE TABLE IF NOT EXISTS product_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  viewed_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_user ON cart_items(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_product_views_user ON product_views(user_id);
CREATE INDEX IF NOT EXISTS idx_product_views_product ON product_views(product_id);

-- Enable Row Level Security
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_views ENABLE ROW LEVEL SECURITY;

-- RLS Policies for categories (public read)
CREATE POLICY "Categories are viewable by everyone"
  ON categories FOR SELECT
  TO authenticated, anon
  USING (true);

-- RLS Policies for products (public read)
CREATE POLICY "Products are viewable by everyone"
  ON products FOR SELECT
  TO authenticated, anon
  USING (true);

-- RLS Policies for cart_items
CREATE POLICY "Users can view own cart items"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own cart items"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart items"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own cart items"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for orders
CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for order_items
CREATE POLICY "Users can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- RLS Policies for product_views
CREATE POLICY "Anyone can create product views"
  ON product_views FOR INSERT
  TO authenticated, anon
  WITH CHECK (true);

CREATE POLICY "Users can view own product views"
  ON product_views FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert sample categories
INSERT INTO categories (name, slug, description, image_url) VALUES
('Electronics', 'electronics', 'Cutting-edge gadgets and devices', 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=800'),
('Fashion', 'fashion', 'Trendy clothing and accessories', 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=800'),
('Home & Living', 'home-living', 'Beautiful home decor and furniture', 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800'),
('Sports & Outdoors', 'sports-outdoors', 'Gear for active lifestyles', 'https://images.pexels.com/photos/235922/pexels-photo-235922.jpeg?auto=compress&cs=tinysrgb&w=800')
ON CONFLICT (slug) DO NOTHING;

-- Insert sample products
INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Wireless Headphones',
  'wireless-headphones',
  'Premium noise-cancelling wireless headphones with superior sound quality and all-day comfort',
  299.99,
  'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  50,
  true,
  4.8
FROM categories WHERE slug = 'electronics'
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Smart Watch Pro',
  'smart-watch-pro',
  'Feature-packed smartwatch with fitness tracking, heart rate monitoring, and notifications',
  399.99,
  'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  30,
  true,
  4.6
FROM categories WHERE slug = 'electronics'
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Designer Leather Jacket',
  'designer-leather-jacket',
  'Stylish genuine leather jacket with modern fit and premium craftsmanship',
  499.99,
  'https://images.pexels.com/photos/1124468/pexels-photo-1124468.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  20,
  true,
  4.9
FROM categories WHERE slug = 'fashion'
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Classic Sneakers',
  'classic-sneakers',
  'Comfortable and versatile sneakers perfect for everyday wear',
  89.99,
  'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  100,
  false,
  4.5
FROM categories WHERE slug = 'fashion'
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Modern Coffee Table',
  'modern-coffee-table',
  'Elegant minimalist coffee table with storage compartment',
  349.99,
  'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  15,
  false,
  4.7
FROM categories WHERE slug = 'home-living'
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Luxury Bed Sheets Set',
  'luxury-bed-sheets',
  'Ultra-soft Egyptian cotton bed sheets for ultimate comfort',
  129.99,
  'https://images.pexels.com/photos/545012/pexels-photo-545012.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  40,
  false,
  4.8
FROM categories WHERE slug = 'home-living'
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Professional Yoga Mat',
  'professional-yoga-mat',
  'Non-slip eco-friendly yoga mat with perfect cushioning',
  59.99,
  'https://images.pexels.com/photos/3822906/pexels-photo-3822906.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  60,
  false,
  4.6
FROM categories WHERE slug = 'sports-outdoors'
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, image_url, category_id, stock, featured, rating) 
SELECT 
  'Mountain Bike Helmet',
  'mountain-bike-helmet',
  'Lightweight protective helmet with adjustable fit and ventilation',
  79.99,
  'https://images.pexels.com/photos/100582/pexels-photo-100582.jpeg?auto=compress&cs=tinysrgb&w=800',
  id,
  35,
  false,
  4.7
FROM categories WHERE slug = 'sports-outdoors'
ON CONFLICT (slug) DO NOTHING;